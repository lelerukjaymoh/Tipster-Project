$(function(){
$( ".datepicker" ).datepicker();
//    function() {
//      $( ".datepicker" ).datepicker( "option", "showAnim", $( this ).val() );
   });